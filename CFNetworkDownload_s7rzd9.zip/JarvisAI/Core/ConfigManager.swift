import Foundation

/// Port of config.py — same keys, same defaults, persisted via UserDefaults.
/// v2.3 defaults match the BROWSER CODING FIX build.
final class ConfigManager: ObservableObject {
    @Published var apiKey: String = "" { didSet { save() } }
    @Published var model: String = "kimi-k3" { didSet { save() } }
    @Published var apiBase: String = "https://api.moonshot.cn/v1" { didSet { save() } }
    @Published var wakeWord: String = "wake up jarvis" { didSet { save() } }
    @Published var codeModel: String = "llama3.1:8b" { didSet { save() } }
    @Published var cameraEnabled: Bool = true { didSet { save() } }
    @Published var hologramEnabled: Bool = true { didSet { save() } }

    /// Mirrors DEFAULT_CONFIG in the original config.py.
    private let defaults: [String: Any] = [
        "api_base": "https://api.moonshot.cn/v1",
        "model": "kimi-k3",
        "wake_word": "wake up jarvis",
        "activation_response": "At your service sir",
        "code_model": "llama3.1:8b",
        "ollama_model": "llama3.1:8b",
        "voice_interruption": true,
        "camera_enabled": true,
        "gesture_control": true,
        "tts_voice": "butler",
        "tts_rate": 210,
        "hologram_enabled": true,
        "hologram_particles": 3000,
        "hologram_color": "cyan",
        "mute_key": "delete",
        "mute_visual_indicator": true,
    ]

    init() {
        let s = UserDefaults.standard
        apiKey = s.string(forKey: "api_key") ?? ""
        model = s.string(forKey: "model") ?? (defaults["model"] as? String ?? "kimi-k3")
        apiBase = s.string(forKey: "api_base") ?? (defaults["api_base"] as? String ?? "")
        wakeWord = s.string(forKey: "wake_word") ?? (defaults["wake_word"] as? String ?? "")
        codeModel = s.string(forKey: "code_model") ?? (defaults["code_model"] as? String ?? "")
        cameraEnabled = s.object(forKey: "camera_enabled") == nil ? true : s.bool(forKey: "camera_enabled")
        hologramEnabled = s.object(forKey: "hologram_enabled") == nil ? true : s.bool(forKey: "hologram_enabled")
    }

    func string(_ key: String) -> String {
        defaults[key] as? String ?? ""
    }

    func save() {
        let s = UserDefaults.standard
        s.set(apiKey, forKey: "api_key")
        s.set(model, forKey: "model")
        s.set(apiBase, forKey: "api_base")
        s.set(wakeWord, forKey: "wake_word")
        s.set(codeModel, forKey: "code_model")
        s.set(cameraEnabled, forKey: "camera_enabled")
        s.set(hologramEnabled, forKey: "hologram_enabled")
    }
}
