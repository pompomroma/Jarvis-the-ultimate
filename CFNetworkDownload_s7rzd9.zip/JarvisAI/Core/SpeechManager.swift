import Foundation
import Speech
import AVFoundation

/// iOS replacement for audio_engine.py + speechrecognition.
/// Wake-word loop plus one-shot command listening, using on-device
/// speech recognition where the device supports it.
final class SpeechManager: ObservableObject {
    var onWakeWord: (() -> Void)?
    var onCommand: ((String) -> Void)?

    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private let engine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?

    private enum Mode { case idle, wake, command }
    private var mode: Mode = .idle

    func requestPermissions(_ completion: @escaping (Bool) -> Void) {
        SFSpeechRecognizer.requestAuthorization { status in
            let speechOK = status == .authorized
            AVAudioSession.sharedInstance().requestRecordPermission { micOK in
                DispatchQueue.main.async { completion(speechOK && micOK) }
            }
        }
    }

    func startWakeWordLoop() {
        start(mode: .wake)
    }

    func listenOnce() {
        start(mode: .command)
    }

    private func start(mode newMode: Mode) {
        stopRecognition()
        guard let recognizer = recognizer, recognizer.isAvailable else { return }
        mode = newMode

        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.record, mode: .measurement, options: .duckOthers)
        try? session.setActive(true, options: .notifyOthersOnDeactivation)

        let req = SFSpeechAudioBufferRecognitionRequest()
        req.shouldReportPartialResults = true
        req.requiresOnDeviceRecognition = recognizer.supportsOnDeviceRecognition
        request = req

        let input = engine.inputNode
        input.removeTap(onBus: 0)
        input.installTap(onBus: 0, bufferSize: 1024, format: input.outputFormat(forBus: 0)) { [weak self] buffer, _ in
            self?.request?.append(buffer)
        }
        engine.prepare()
        do {
            try engine.start()
        } catch {
            stopRecognition()
            return
        }

        task = recognizer.recognitionTask(with: req) { [weak self] result, error in
            guard let self = self else { return }
            let text = result?.bestTranscription.formattedString.lowercased() ?? ""
            let isFinal = result?.isFinal ?? false
            if !text.isEmpty {
                self.handleTranscription(text, final: isFinal)
            }
            if error != nil || isFinal {
                let current = self.mode
                self.stopRecognition()
                if current != .idle {
                    self.start(mode: current)
                }
            }
        }
    }

    private func handleTranscription(_ text: String, final: Bool) {
        let wake = "wake up jarvis"
        switch mode {
        case .wake:
            if text.contains(wake) {
                stopAll()
                mode = .idle
                onWakeWord?()
            }
        case .command:
            if final {
                stopAll()
                mode = .idle
                var cleaned = text.replacingOccurrences(of: wake, with: "")
                cleaned = cleaned.trimmingCharacters(in: .whitespacesAndNewlines)
                if !cleaned.isEmpty {
                    onCommand?(cleaned)
                }
                startWakeWordLoop()
            }
        case .idle:
            break
        }
    }

    func stopRecognition() {
        task?.cancel()
        task = nil
        request?.endAudio()
        request = nil
    }

    private func stopAll() {
        stopRecognition()
        engine.inputNode.removeTap(onBus: 0)
        engine.stop()
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }
}
