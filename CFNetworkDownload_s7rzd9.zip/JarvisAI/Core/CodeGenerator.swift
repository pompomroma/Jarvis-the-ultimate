import Foundation

/// Port of code_generator.py — same system prompt, same temperature 0.2,
/// same max_tokens, cloud API with local fallback slot.
final class CodeGenerator {
    func generate(prompt: String, language: String, config: ConfigManager,
                  completion: @escaping (String) -> Void) {
        guard !config.apiKey.isEmpty else {
            completion("I need an API key first, sir. Open Settings and add your Moonshot key.")
            return
        }
        guard let url = URL(string: config.apiBase + "/chat/completions") else {
            completion("Invalid API base URL, sir.")
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(config.apiKey)", forHTTPHeaderField: "Authorization")
        request.timeoutInterval = 120

        let system = "You are an expert software engineer. Generate complete, runnable code. Include all necessary files, dependencies, and setup instructions. Output ONLY the code and file structure, no explanations."
        let body: [String: Any] = [
            "model": config.model,
            "messages": [
                ["role": "system", "content": system],
                ["role": "user", "content": "Create a \(language) project: \(prompt)"],
            ],
            "temperature": 0.2,
            "max_tokens": 4000,
        ]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                completion("Code generation failed, sir: \(error.localizedDescription)")
                return
            }
            guard
                let data = data,
                let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                let choices = json["choices"] as? [[String: Any]],
                let first = choices.first,
                let message = first["message"] as? [String: Any],
                let content = message["content"] as? String
            else {
                completion("I could not parse the generated code, sir.")
                return
            }
            completion(content)
        }.resume()
    }

    /// Mirrors the desktop build saving projects into ~/ACTIG_Projects.
    /// iOS equivalent: the app's Documents/ACTIG_Projects folder.
    @discardableResult
    func saveProject(_ code: String, language: String) -> URL? {
        guard let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            return nil
        }
        let dir = docs.appendingPathComponent("ACTIG_Projects", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let stamp = Int(Date().timeIntervalSince1970)
        let ext: String
        switch language {
        case "python": ext = "py"
        case "javascript": ext = "js"
        case "html": ext = "html"
        case "css": ext = "css"
        case "swift": ext = "swift"
        default: ext = "txt"
        }
        let file = dir.appendingPathComponent("project_\(stamp).\(ext)")
        do {
            try code.write(to: file, atomically: true, encoding: .utf8)
            return file
        } catch {
            return nil
        }
    }
}
