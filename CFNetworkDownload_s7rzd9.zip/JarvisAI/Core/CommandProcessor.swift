import UIKit
import MediaPlayer

/// Port of the v2.3 voice-command grammar in main.py / system_controller.py.
/// Browser commands drive the in-app tabbed browser; coding commands open
/// Coding Mode; Windows-only commands gracefully report [FALLBACK] behavior.
final class CommandProcessor {
    private weak var brain: JarvisBrain?

    init(brain: JarvisBrain) {
        self.brain = brain
    }

    private let appSchemes: [String: String] = [
        "chrome": "googlechrome://",
        "spotify": "spotify://",
        "discord": "discord://",
        "youtube": "youtube://",
        "maps": "maps://",
        "music": "music://",
        "safari": "https://www.apple.com",
    ]

    func process(_ raw: String) {
        let text = raw.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)

        // === SYSTEM POWER (Windows-only, graceful fallback like the original) ===
        if text.contains("shutdown") || text.contains("restart") || text.contains("lock pc") {
            respond("Full system power control is restricted by iOS, sir. That command only exists in the desktop build.")
            return
        }

        // === CODING MODE (v2.3) ===
        if any(text, ["generate code", "create app", "build game", "make website",
                      "vibe code", "write code", "open coding mode", "coding mode", "open coding tab"]) {
            brain?.mainTab = 2
            respond("Coding mode engaged, sir.", speak: "Coding mode engaged, sir.")
            return
        }
        if any(text, ["shut down coding mode", "close coding tab", "exit coding mode", "close coding mode"]) {
            brain?.mainTab = 0
            respond("Coding mode closed, sir.")
            return
        }

        // === BROWSER INTERACTION (v2.3 fixed set) ===
        if any(text, ["open browser", "attach browser", "connect browser"]) {
            brain?.mainTab = 1
            respond("Browser at your service, sir.", speak: "Browser at your service, sir.")
            return
        }
        if text.contains("close browser") {
            brain?.mainTab = 0
            respond("Browser minimised, sir.")
            return
        }
        if any(text, ["new tab", "open tab"]) {
            brain?.browser.newTab()
            respond("New tab opened, sir.")
            return
        }
        if any(text, ["close tab", "close the tab"]) {
            brain?.browser.closeSelectedTab()
            respond("Tab closed, sir.")
            return
        }
        if text.hasPrefix("switch to tab") {
            let digits = text.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
            if let n = Int(digits) {
                if brain?.browser.selectTab(n - 1) == true {
                    respond("Switching to tab \(n), sir.")
                } else {
                    respond("There is no tab \(n), sir.")
                }
            } else {
                respond("Which tab number, sir?")
            }
            return
        }
        if text.hasPrefix("navigate to ") || text.hasPrefix("go to ") {
            let target = text
                .replacingOccurrences(of: "navigate to ", with: "")
                .replacingOccurrences(of: "go to ", with: "")
                .trimmingCharacters(in: .whitespaces)
            brain?.browser.navigate(target)
            respond("Navigating to \(target), sir.")
            return
        }
        if text.contains("read this page") || text.contains("read the page") || text.contains("read page") {
            brain?.browser.readPage { [weak self] content in
                guard let self = self, let brain = self.brain else { return }
                let clipped = String(content.prefix(600))
                brain.say("JARVIS (page): \(clipped)")
                brain.tts.speak(String(content.prefix(300)))
            }
            respond("Reading the page, sir.")
            return
        }
        if text.contains("scroll down") {
            brain?.browser.scroll(down: true)
            respond("Scrolling down, sir.")
            return
        }
        if text.contains("scroll up") {
            brain?.browser.scroll(down: false)
            respond("Scrolling up, sir.")
            return
        }
        if text.hasPrefix("search the web") || text.hasPrefix("search for") || text.hasPrefix("google") {
            let query = text
                .replacingOccurrences(of: "search the web for", with: "")
                .replacingOccurrences(of: "search the web", with: "")
                .replacingOccurrences(of: "search for", with: "")
                .replacingOccurrences(of: "google", with: "")
                .trimmingCharacters(in: .whitespaces)
            if let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
                brain?.browser.navigate("https://www.google.com/search?q=\(encoded)")
                respond("Searching the web for \(query), sir.")
            }
            return
        }

        // === APPS & MEDIA ===
        if text.hasPrefix("close ") {
            respond("iOS does not permit one app to close another, sir. That ability is exclusive to the desktop build.")
            return
        }
        if text.hasPrefix("open ") {
            openApp(String(text.dropFirst(5)))
            return
        }
        if text.hasPrefix("set volume") {
            let digits = text.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
            setVolume(Int(digits) ?? 50)
            return
        }
        if text.contains("what do you see") {
            brain?.say("JARVIS: Opening the camera, sir.")
            brain?.startVision()
            return
        }
        if text.hasPrefix("play music") {
            let query = text.replacingOccurrences(of: "play music", with: "")
                .trimmingCharacters(in: .whitespaces)
            if let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
               openURL("spotify://search/\(encoded)") {
                respond("Searching Spotify for \(query), sir.", speak: "Searching Spotify, sir.")
            } else {
                respond("Spotify does not appear to be installed, sir.")
            }
            return
        }
        if text.contains("hologram") || text.contains("open 3d") {
            brain?.showHologram = true
            respond("Engaging holographic interface, sir.", speak: "Engaging holographic interface, sir.")
            return
        }

        // === DEFAULT: general knowledge via the AI ===
        brain?.askLLM(raw)
    }

    private func any(_ text: String, _ phrases: [String]) -> Bool {
        phrases.contains { text.contains($0) }
    }

    private func openApp(_ name: String) {
        let key = name.trimmingCharacters(in: .whitespaces)
        guard let scheme = appSchemes[key] else {
            respond("I don't have a launch path for \(key), sir.")
            return
        }
        if openURL(scheme) {
            respond("Opening \(key), sir.", speak: "Opening \(key), sir.")
        } else {
            respond("\(key) does not appear to be installed, sir.")
        }
    }

    @discardableResult
    private func openURL(_ string: String) -> Bool {
        guard let url = URL(string: string), UIApplication.shared.canOpenURL(url) else { return false }
        UIApplication.shared.open(url)
        return true
    }

    /// Same intent as "Set volume [0-100]" via MPVolumeView's hidden slider,
    /// the only sanctioned way to affect system media volume on iOS.
    private func setVolume(_ value: Int) {
        let clamped = max(0, min(100, value))
        let volumeView = MPVolumeView()
        if let window = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .flatMap({ $0.windows })
            .first {
            volumeView.frame = CGRect(x: -1000, y: -1000, width: 1, height: 1)
            window.addSubview(volumeView)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            if let slider = volumeView.subviews.first(where: { $0 is UISlider }) as? UISlider {
                slider.setValue(Float(clamped) / 100.0, animated: false)
            }
        }
        respond("Volume set to \(clamped) percent, sir.", speak: "Volume set to \(clamped) percent, sir.")
    }

    private func respond(_ text: String, speak spoken: String? = nil) {
        brain?.say("JARVIS: \(text)")
        brain?.tts.speak(spoken ?? text)
    }
}
