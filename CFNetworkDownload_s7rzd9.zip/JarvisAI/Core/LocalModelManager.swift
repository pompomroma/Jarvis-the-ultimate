import Foundation

/// Equivalent slot for the original's ollama_client.py local path.
///
/// Ollama is a Go server and cannot run on iOS. The closest faithful
/// replacement is llama.cpp (the engine Ollama itself is built on)
/// compiled into the app, loading the same llama3.1:8b GGUF model.
///
/// To enable fully on-device inference:
///   1. Add the llama.cpp Swift package (github.com/ggml-org/llama.cpp,
///      product "LlamaSwift") to project.yml under dependencies.
///   2. Bundle a llama3.1-8b Q4_K_M.gguf (about 4.9 GB) as a resource,
///      downloaded on first launch to Documents (App Store size limits).
///   3. Replace the body of generate() with an LLamaContext session.
///
/// Until then this class reports the same fallback message the desktop
/// agent shows when Ollama is unreachable.
final class LocalModelManager: ObservableObject {
    @Published var isModelLoaded = false

    var modelName: String { "llama3.1:8b" }

    func generate(prompt: String, completion: @escaping (String) -> Void) {
        completion("Local model slot is not populated in this build, sir. Cloud mode is active. See LocalModelManager.swift to enable on-device llama.cpp inference.")
    }
}
