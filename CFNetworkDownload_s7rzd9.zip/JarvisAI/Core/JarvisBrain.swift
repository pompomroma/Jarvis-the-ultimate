import Foundation
import SwiftUI

/// Central orchestrator — the iOS equivalent of main.py's module wiring.
/// v2.3: browser tab engine, coding mode, expanded command grammar.
final class JarvisBrain: ObservableObject {
    @Published var log: [String] = []
    @Published var isAwake = false
    @Published var isListening = false
    @Published var isSpeaking = false
    @Published var showHologram = false
    @Published var showVision = false
    @Published var mainTab = 0

    let config = ConfigManager()
    let tts = TTSManager()
    let browser = BrowserManager()
    private(set) lazy var speech = SpeechManager()
    private(set) lazy var commands = CommandProcessor(brain: self)
    private(set) lazy var vision = VisionManager()
    private let moonshot = MoonshotClient()

    init() {
        tts.onState = { [weak self] speaking in
            DispatchQueue.main.async { self?.isSpeaking = speaking }
        }
        speech.onWakeWord = { [weak self] in
            DispatchQueue.main.async { self?.activate() }
        }
        speech.onCommand = { [weak self] text in
            DispatchQueue.main.async { self?.handle(text) }
        }
    }

    /// Entry point — equivalent of RUN_NATIVE.bat.
    func start() {
        browser.newTab(url: "https://www.google.com")
        speech.requestPermissions { [weak self] ok in
            guard let self else { return }
            if ok {
                self.say("[OK] Audio engine ready. Say \"\(self.config.wakeWord)\".")
                self.speech.startWakeWordLoop()
                self.isListening = true
            } else {
                self.say("[ERROR] Microphone/speech permission denied. Enable both in iOS Settings > JARVIS.")
            }
        }
    }

    func activate() {
        guard !isAwake else { return }
        isAwake = true
        let phrase = config.string("activation_response")
        say("JARVIS: \(phrase)")
        tts.speak(phrase)
        speech.listenOnce()
    }

    func handle(_ text: String) {
        isAwake = false
        say("You: \(text)")
        commands.process(text)
    }

    func askLLM(_ prompt: String) {
        say("JARVIS is thinking...")
        moonshot.chat(prompt, config: config) { [weak self] reply in
            DispatchQueue.main.async {
                self?.say("JARVIS: \(reply)")
                self?.tts.speak(reply)
            }
        }
    }

    func startVision() {
        guard config.cameraEnabled else {
            say("JARVIS: Camera is disabled in Settings, sir.")
            return
        }
        showVision = true
        vision.start()
        vision.describeScene { [weak self] description in
            DispatchQueue.main.async {
                self?.say("JARVIS: \(description)")
                self?.tts.speak(description)
            }
        }
    }

    func say(_ text: String) {
        log.append(text)
    }
}
