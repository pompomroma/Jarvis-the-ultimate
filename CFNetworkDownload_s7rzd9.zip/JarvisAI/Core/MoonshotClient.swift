import Foundation

/// Direct port of ollama_client.py's cloud path: OpenAI-compatible
/// chat completions against api.moonshot.cn (config: api_base, api_key, model).
final class MoonshotClient {
    func chat(_ prompt: String, config: ConfigManager, completion: @escaping (String) -> Void) {
        guard !config.apiKey.isEmpty else {
            completion("I need an API key first, sir. Please open Settings and add your Moonshot key.")
            return
        }
        guard let url = URL(string: config.apiBase + "/chat/completions") else {
            completion("Invalid API base URL, sir.")
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(config.apiKey)", forHTTPHeaderField: "Authorization")
        request.timeoutInterval = 30

        let body: [String: Any] = [
            "model": config.model,
            "messages": [["role": "user", "content": prompt]],
            "temperature": 0.7,
        ]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                completion("API error: \(error.localizedDescription)")
                return
            }
            guard
                let data = data,
                let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                let choices = json["choices"] as? [[String: Any]],
                let first = choices.first,
                let message = first["message"] as? [String: Any],
                let content = message["content"] as? String
            else {
                let raw = data.flatMap { String(data: $0, encoding: .utf8) } ?? "no data"
                completion("I could not parse the model response, sir. Raw: \(raw.prefix(200))")
                return
            }
            completion(content)
        }.resume()
    }
}
