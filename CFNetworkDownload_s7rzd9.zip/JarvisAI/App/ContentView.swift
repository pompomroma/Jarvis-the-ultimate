import SwiftUI

struct ContentView: View {
    @EnvironmentObject var brain: JarvisBrain
    @State private var typed = ""
    @State private var addressBar = ""

    var body: some View {
        ZStack {
            TabView(selection: $brain.mainTab) {
                home
                    .tabItem { Label("JARVIS", systemImage: "waveform") }
                    .tag(0)

                browserTab
                    .tabItem { Label("Browser", systemImage: "globe") }
                    .tag(1)

                CodingView()
                    .tabItem { Label("Coding", systemImage: "chevron.left.forwardslash.chevron.right") }
                    .tag(2)

                SettingsView()
                    .tabItem { Label("Settings", systemImage: "gear") }
                    .tag(3)
            }

            if brain.showHologram && brain.config.hologramEnabled {
                HologramView()
                    .ignoresSafeArea()
                    .onTapGesture { brain.showHologram = false }
            }
        }
        .onAppear { brain.start() }
    }

    // MARK: - Home (voice console)

    var home: some View {
        NavigationStack {
            VStack(spacing: 0) {
                statusBar
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 6) {
                            ForEach(Array(brain.log.enumerated()), id: \.offset) { index, line in
                                Text(line)
                                    .font(.system(.body, design: .monospaced))
                                    .foregroundColor(line.hasPrefix("JARVIS") ? .cyan : .primary)
                                    .id(index)
                            }
                        }
                        .padding()
                    }
                    .onChange(of: brain.log.count) { _ in
                        if !brain.log.isEmpty {
                            proxy.scrollTo(brain.log.count - 1, anchor: .bottom)
                        }
                    }
                }
                HStack {
                    TextField("Type a command, sir", text: $typed)
                        .textFieldStyle(.roundedBorder)
                        .autocapitalization(.none)
                        .onSubmit(submit)
                    Button("Send") { submit() }
                        .disabled(typed.trimmingCharacters(in: .whitespaces).isEmpty)
                }
                .padding()
            }
            .navigationTitle("ACTIG Agent v2.3 — iOS")
        }
    }

    var statusBar: some View {
        HStack(spacing: 8) {
            Circle()
                .fill(brain.isListening ? Color.green : Color.gray)
                .frame(width: 10, height: 10)
            Text(brain.isListening ? "Listening for: \"\(brain.config.wakeWord)\"" : "Idle")
                .font(.caption)
            Spacer()
            if brain.isSpeaking {
                Text("Speaking...")
                    .font(.caption)
                    .foregroundColor(.cyan)
            }
        }
        .padding(.horizontal)
        .padding(.top, 4)
    }

    // MARK: - Browser (v2.3 tabbed engine)

    var browserTab: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Tab strip
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(Array(brain.browser.tabs.enumerated()), id: \.element.id) { index, tab in
                            Button(action: { brain.browser.selectedID = tab.id }) {
                                HStack(spacing: 4) {
                                    Image(systemName: tab.id == brain.browser.selectedID ? "circle.fill" : "circle")
                                        .font(.system(size: 7))
                                    Text("Tab \(index + 1)")
                                        .font(.caption)
                                }
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(tab.id == brain.browser.selectedID ? Color.cyan.opacity(0.25) : Color.gray.opacity(0.15))
                                .cornerRadius(14)
                            }
                            .foregroundColor(.primary)
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical, 6)

                // Address bar
                HStack {
                    TextField("Enter URL or search, sir", text: $addressBar)
                        .textFieldStyle(.roundedBorder)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                        .onSubmit { go() }
                    Button("Go") { go() }
                    Button(action: { brain.browser.newTab() }) {
                        Image(systemName: "plus.square")
                    }
                    Button(action: { brain.browser.closeSelectedTab() }) {
                        Image(systemName: "xmark.square")
                    }
                }
                .padding(.horizontal)

                // Active tab content
                if let tab = brain.browser.selectedTab {
                    WebView(tab: tab)
                } else {
                    Spacer()
                    Text("Say \"open browser\" or tap + to start, sir.")
                        .foregroundColor(.secondary)
                    Spacer()
                }
            }
            .navigationTitle("Browser Control")
        }
    }

    func go() {
        let target = addressBar.trimmingCharacters(in: .whitespaces)
        guard !target.isEmpty else { return }
        if target.contains(".") && !target.contains(" ") {
            brain.browser.navigate(target)
        } else if let encoded = target.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
            brain.browser.navigate("https://www.google.com/search?q=\(encoded)")
        }
        addressBar = ""
    }

    func submit() {
        let text = typed.trimmingCharacters(in: .whitespaces)
        guard !text.isEmpty else { return }
        typed = ""
        brain.handle(text)
    }
}

/// Wraps a tab's WKWebView for SwiftUI.
struct WebView: UIViewRepresentable {
    @ObservedObject var tab: BrowserTab

    func makeUIView(context: Context) -> WKWebView {
        tab.webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Coding Mode (port of coding_tab.py "Vibe Programming")

struct CodingView: View {
    @EnvironmentObject var brain: JarvisBrain
    @State private var prompt = ""
    @State private var language = "python"
    @State private var output = ""
    @State private var isWorking = false
    @State private var savedPath = ""

    private let languages = ["python", "javascript", "html", "css", "swift", "java", "c++", "go", "rust", "sql"]
    private let generator = CodeGenerator()

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Prompt bar — same layout as the desktop coding tab
                HStack {
                    TextField("Describe the project, sir (e.g. snake game)", text: $prompt)
                        .textFieldStyle(.roundedBorder)
                        .autocapitalization(.none)
                        .onSubmit(generate)
                    Picker("Language", selection: $language) {
                        ForEach(languages, id: \.self) { Text($0).tag($0) }
                    }
                    .pickerStyle(.menu)
                    Button(isWorking ? "Working..." : "Generate") { generate() }
                        .disabled(isWorking || prompt.trimmingCharacters(in: .whitespaces).isEmpty)
                }
                .padding()

                // Editor output
                ScrollView {
                    Text(output.isEmpty ? "// Generated code will appear here, sir." : output)
                        .font(.system(.caption, design: .monospaced))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .textSelection(.enabled)
                }
                .background(Color(red: 0.04, green: 0.055, blue: 0.15))

                // Action bar — upload/download equivalents: copy + save to ACTIG_Projects
                HStack {
                    Button(action: copyOutput) {
                        Label("Copy", systemImage: "doc.on.doc")
                    }
                    .disabled(output.isEmpty)
                    Button(action: saveOutput) {
                        Label("Save Project", systemImage: "square.and.arrow.down")
                    }
                    .disabled(output.isEmpty)
                    Spacer()
                    if !savedPath.isEmpty {
                        Text("Saved: \(savedPath)")
                            .font(.caption2)
                            .foregroundColor(.green)
                            .lineLimit(1)
                    }
                }
                .padding()
            }
            .navigationTitle("Coding Mode")
        }
    }

    func generate() {
        let request = prompt.trimmingCharacters(in: .whitespaces)
        guard !request.isEmpty else { return }
        isWorking = true
        savedPath = ""
        brain.say("JARVIS: Generating \(language) project: \(request)")
        generator.generate(prompt: request, language: language, config: brain.config) { result in
            DispatchQueue.main.async {
                self.output = result
                self.isWorking = false
                self.brain.say("JARVIS: Code generation complete, sir.")
                self.brain.tts.speak("Code generation complete, sir")
            }
        }
    }

    func copyOutput() {
        UIPasteboard.general.string = output
        brain.say("JARVIS: Code copied to clipboard, sir.")
    }

    func saveOutput() {
        if let url = generator.saveProject(output, language: language) {
            savedPath = url.lastPathComponent
            brain.say("JARVIS: Project saved to ACTIG_Projects, sir.")
        } else {
            brain.say("JARVIS: I could not save the project, sir.")
        }
    }
}

// MARK: - Settings

struct SettingsView: View {
    @EnvironmentObject var brain: JarvisBrain

    var body: some View {
        Form {
            Section("AI (Cloud)") {
                SecureField("Moonshot API key", text: $brain.config.apiKey)
                TextField("Model", text: $brain.config.model)
                    .autocapitalization(.none)
                TextField("API base URL", text: $brain.config.apiBase)
                    .autocapitalization(.none)
            }
            Section("Voice") {
                TextField("Wake word", text: $brain.config.wakeWord)
                    .autocapitalization(.none)
            }
            Section("Coding") {
                TextField("Code model (local slot)", text: $brain.config.codeModel)
                    .autocapitalization(.none)
            }
            Section("Interface") {
                Toggle("Camera enabled", isOn: $brain.config.cameraEnabled)
                Toggle("Hologram enabled", isOn: $brain.config.hologramEnabled)
            }
            Section("About") {
                Text("Port of ACTIG Agent v2.3 (JARVIS Edition, Browser Coding Fix build). Features that require Windows (PC shutdown/restart/lock, closing other apps, desktop window automation) are gracefully disabled, matching the original's [FALLBACK] behavior.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
    }
}
