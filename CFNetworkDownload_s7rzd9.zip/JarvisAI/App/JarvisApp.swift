import SwiftUI

@main
struct JarvisApp: App {
    @StateObject private var brain = JarvisBrain()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(brain)
        }
    }
}
