import Foundation
import WebKit

/// A single browser tab. Each tab owns its WKWebView, exactly like the
/// v2.3 desktop build attaches to real Chrome tabs.
final class BrowserTab: Identifiable, ObservableObject {
    let id = UUID()
    @Published var url: String
    let webView: WKWebView

    init(url: String) {
        self.url = url
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        self.webView = WKWebView(frame: .zero, configuration: configuration)
        self.webView.allowsBackForwardNavigationGestures = true
        load(url)
    }

    func load(_ raw: String) {
        let trimmed = raw.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return }
        let withScheme = trimmed.contains("://") ? trimmed : "https://" + trimmed
        guard let url = URL(string: withScheme) else { return }
        self.url = withScheme
        webView.load(URLRequest(url: url))
    }
}

/// Port of the v2.3 browser-fix engine: tab management, navigation,
/// page reading (JS text extraction), and scrolling.
final class BrowserManager: ObservableObject {
    @Published var tabs: [BrowserTab] = []
    @Published var selectedID: UUID?

    var selectedTab: BrowserTab? {
        tabs.first { $0.id == selectedID }
    }

    @discardableResult
    func newTab(url: String = "https://www.google.com") -> BrowserTab {
        let tab = BrowserTab(url: url)
        tabs.append(tab)
        selectedID = tab.id
        return tab
    }

    func closeSelectedTab() {
        guard let id = selectedID, let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        tabs[index].webView.stopLoading()
        tabs.remove(at: index)
        if tabs.isEmpty {
            newTab()
        } else {
            selectedID = tabs[min(index, tabs.count - 1)].id
        }
    }

    @discardableResult
    func selectTab(_ index: Int) -> Bool {
        guard tabs.indices.contains(index) else { return false }
        selectedID = tabs[index].id
        return true
    }

    func navigate(_ url: String) {
        if let tab = selectedTab {
            tab.load(url)
        } else {
            newTab(url: url)
        }
    }

    /// "Read this page" — extract visible text via JavaScript,
    /// the iOS equivalent of the desktop build's page parser.
    func readPage(completion: @escaping (String) -> Void) {
        guard let tab = selectedTab else {
            completion("No browser tab is open, sir.")
            return
        }
        tab.webView.evaluateJavaScript("document.body.innerText") { result, _ in
            if let text = result as? String, !text.trimmingCharacters(in: .whitespaces).isEmpty {
                completion(text.trimmingCharacters(in: .whitespacesAndNewlines))
            } else {
                completion("I could not extract text from this page, sir.")
            }
        }
    }

    /// "Scroll up/down" — JS-driven, same visual result as the desktop build.
    func scroll(down: Bool) {
        guard let tab = selectedTab else { return }
        let pixels = down ? 600 : -600
        tab.webView.evaluateJavaScript("window.scrollBy(0, \(pixels))", completionHandler: nil)
    }
}
