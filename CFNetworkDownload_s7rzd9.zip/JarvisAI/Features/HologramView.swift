import SwiftUI

/// SwiftUI port of jarvis_hologram.py — cyan particle ring (default 3000).
struct HologramView: View {
    let particleCount = 3000

    var body: some View {
        TimelineView(.animation) { timeline in
            Canvas { context, size in
                let t = timeline.date.timeIntervalSinceReferenceDate
                let center = CGPoint(x: size.width / 2, y: size.height / 2)
                let radius = min(size.width, size.height) * 0.3

                for i in 0..<particleCount {
                    let f = Double(i)
                    let angle = f * 0.02 + t * 0.6
                    let r = radius * (0.6 + 0.4 * sin(f * 0.37 + t))
                    let point = CGPoint(
                        x: center.x + cos(angle) * r,
                        y: center.y + sin(angle) * r * 0.55
                    )
                    let rect = CGRect(x: point.x, y: point.y, width: 1.6, height: 1.6)
                    let glow = 0.25 + 0.5 * abs(sin(f + t * 2))
                    context.fill(
                        Path(ellipseIn: rect),
                        with: .color(Color.cyan.opacity(glow))
                    )
                }
            }
        }
        .background(Color.black)
    }
}
