import AVFoundation
import Vision

/// iOS replacement for vision_module.py (opencv + mediapipe).
/// Live camera capture via AVFoundation; scene description hooks the
/// Vision framework. Bundle a CoreML classification/detection model and
/// drop it into classify() to match the desktop camera features fully.
final class VisionManager: NSObject, ObservableObject {
    @Published var lastFrameDescription = ""

    let session = AVCaptureSession()
    private var latestImage: CGImage?

    func start() {
        guard !session.isRunning else { return }
        session.beginConfiguration()
        session.sessionPreset = .medium
        guard
            let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
            let input = try? AVCaptureDeviceInput(device: device),
            session.canAddInput(input)
        else {
            session.commitConfiguration()
            lastFrameDescription = "No camera available, sir."
            return
        }
        session.addInput(input)

        let output = AVCaptureVideoDataOutput()
        output.setSampleBufferDelegate(self, queue: DispatchQueue(label: "com.actig.vision"))
        if session.canAddOutput(output) {
            session.addOutput(output)
        }
        session.commitConfiguration()
        DispatchQueue.global(qos: .userInitiated).async {
            self.session.startRunning()
        }
    }

    func stop() {
        if session.isRunning {
            session.stopRunning()
        }
    }

    func describeScene(completion: @escaping (String) -> Void) {
        // Small delay so at least one frame lands before describing.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            guard let self = self else { return }
            if self.latestImage != nil {
                self.lastFrameDescription = "Camera is live, sir. I can see the scene; a CoreML model is required for detailed descriptions."
            } else {
                self.lastFrameDescription = "I am having trouble accessing the camera, sir."
            }
            completion(self.lastFrameDescription)
        }
    }
}

extension VisionManager: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let buffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let ciImage = CIImage(cvImageBuffer: buffer)
        let context = CIContext()
        latestImage = context.createCGImage(ciImage, from: ciImage.extent)
    }
}
