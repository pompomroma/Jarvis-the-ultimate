# JARVIS AI — iOS Edition v2.3 (ACTIG Agent BROWSER CODING FIX port)

Faithful iOS rebuild of the Windows ACTIG Agent v2.3 (JARVIS Edition,
Browser Coding Fix build) from the original Python ZIP. Same command
grammar (including the full v2.3 browser and coding command sets), same
config keys, same defaults, same fallback behavior.

## How to get your IPA (no Mac needed)

1. Create a free GitHub account.
2. Create a new repository named `JarvisAI` (private is fine).
3. Upload **all the files in this folder** to that repository (drag and drop
   on the GitHub web page works — keep the folder structure, including the
   `.github/workflows` folder).
4. Go to the **Actions** tab and click **Run workflow** on "Build IPA".
5. Wait ~10 minutes, then open the finished run and download the
   **JarvisAI-ipa** artifact. That zip contains your `JarvisAI.ipa`.

## Install on your iPhone from Windows

1. Install **Sideloadly** (https://sideloadly.io) or **AltStore** on your PC.
2. Connect your iPhone, drag `JarvisAI.ipa` into Sideloadly, enter your
   Apple ID, and install.
3. On the iPhone: Settings > General > VPN & Device Management > trust your ID.
4. Free Apple IDs re-sign every 7 days — just re-install with Sideloadly
   (AltStore can automate this over Wi-Fi).

## Feature parity vs. the v2.3 ZIP

| Original v2.3 feature | Status in this build |
|---|---|
| Wake word "wake up jarvis" | Works (on-device Speech framework) |
| "At your service sir" activation | Works (en-GB TTS, butler style) |
| Cloud AI (Moonshot api.moonshot.cn, kimi-k3) | Works identically |
| Coding Mode / "vibe programming" tab (coding_tab.py) | Works — same dark/cyan UI, prompt, language picker, editor output, copy/save to ACTIG_Projects |
| "Generate code / create app / build game / make website / vibe code" | Works via Coding Mode (same system prompt, temperature 0.2) |
| Open / Close / Switch browser tabs | Works — tab strip with numbered tabs |
| "Navigate to [url]" | Works |
| "Read this page" | Works — extracts page text via JavaScript, reads it aloud |
| "Scroll up / scroll down" | Works — JS-driven, same visual result |
| "Search the web [query]" | Works (Google search) |
| "Close [app]" | Graceful fallback — iOS forbids one app closing another |
| "Open [app]" / "Play music [song]" | Works via iOS URL schemes (Spotify, Discord, YouTube, Chrome...) |
| "Set volume [0-100]" | Works (system media volume) |
| "What do you see" (camera) | Camera works; add a CoreML model for full descriptions |
| Hologram (3000 cyan particles) | Works (tap to dismiss) |
| Console log + typed commands | Works |
| Settings (API key, model, wake word, code model, toggles) | Works |
| Local model (ollama llama3.1:8b) | Slot ready — see `LocalModelManager.swift` for llama.cpp |
| Shutdown / Restart / Lock PC | Impossible on iOS — graceful fallback message, like the original's [FALLBACK] |
| Desktop window automation (pyautogui/pywin32) | Windows-only — excluded by design |
| apply_all_patches.py | N/A — this build ships with all v2.2/v2.3 fixes already applied |

## Requirements

- iPhone with iOS 16+ (A12 chip or newer recommended)
- Microphone + speech permission, camera permission when asked
- Moonshot API key for cloud AI and code generation (Settings screen inside the app)
